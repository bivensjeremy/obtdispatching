const RequestFormSent = () => {
    return (
        <div className="background">
            <div className="container py-5 text-center">
                <h1 className="fw-bold text-light pt-3">Thank you. Form has been sent. </h1>
                <h2 className="fw-bold text-light pt-3">We will follow up with you with additional details.</h2>
            </div>
        </div>
    );
}

export default RequestFormSent;