(function() {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 1130:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "f": function() { return /* binding */ server; }
/* harmony export */ });
const dev = false;
const server = dev ? 'http://localhost:3000' : 'https://obtdispatchingservice.com';

/***/ }),

/***/ 7273:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ Home; },
  "getServerSideProps": function() { return /* binding */ getServerSideProps; }
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(701);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./components/AboutCard.js



const AboutCard = props => {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "col-md-6 p-1",
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "card about-card h-100 text-center",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "card-body",
        children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "material-icons mi-about",
          children: props.icon
        }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
          className: "card-title",
          children: props.name
        }), /*#__PURE__*/jsx_runtime_.jsx("hr", {
          className: "m-auto"
        }), /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "card-text py-3",
          children: props.data
        })]
      })
    })
  });
};

/* harmony default export */ var components_AboutCard = (AboutCard);
;// CONCATENATED MODULE: ./components/AboutSection.js



function createAboutCard(props) {
  return /*#__PURE__*/jsx_runtime_.jsx(components_AboutCard, {
    icon: props.icon,
    name: props.name,
    header: props.header,
    data: props.data
  }, props.id);
}

function AboutSection(props) {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "container",
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "row px-3",
      children: props.aboutInfo.map(createAboutCard)
    })
  });
}

/* harmony default export */ var components_AboutSection = (AboutSection);
// EXTERNAL MODULE: ./components/ContactSection.js
var ContactSection = __webpack_require__(225);
;// CONCATENATED MODULE: ./components/PricingSection.js



//import PricingCard from "./PricingCard";
// function createPricingCard(props) {
//     return(
//         <PricingCard
//             key={props.id}
//             active={props.active}
//             icon={props.icon}
//             name={props.name}
//             data={props.data}
//         />
//     )
// }
const PricingSection = props => {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      id: "carouselExampleControls",
      className: "carousel slide",
      "data-bs-ride": "carousel",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "carousel-inner",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "carousel-item active",
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "d-block m-auto w-50",
            children: /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "card pricing-card text-center py-5",
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "card-body",
                children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
                  className: "card-title display-4",
                  children: "Communication"
                }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                  className: "material-icons mi-pricing text-white",
                  children: "message"
                }), /*#__PURE__*/jsx_runtime_.jsx("h3", {
                  className: "card-text py-3",
                  children: "Simple and direct communication between client & dispatcher."
                })]
              })
            })
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "carousel-item",
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "d-block m-auto w-50",
            children: /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "card pricing-card text-center py-5",
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "card-body",
                children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
                  className: "card-title display-4",
                  children: "Trusted Experience"
                }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                  className: "material-icons mi-pricing text-white",
                  children: "travel_explore"
                }), /*#__PURE__*/jsx_runtime_.jsx("h3", {
                  className: "card-text py-3",
                  children: "Over 5 years of industry experience trucking and booking loads. "
                })]
              })
            })
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "carousel-item",
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "d-block m-auto w-50",
            children: /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "card pricing-card text-center py-5",
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "card-body",
                children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
                  className: "card-title display-4",
                  children: "Rate Plan"
                }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                  className: "material-icons mi-pricing text-white",
                  children: "request_quote"
                }), /*#__PURE__*/jsx_runtime_.jsx("h3", {
                  className: "card-text py-3",
                  children: "Flat fee of 10% per load making service agreements easy to manage."
                })]
              })
            })
          })
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
        className: "carousel-control-prev",
        type: "button",
        "data-bs-target": "#carouselExampleControls",
        "data-bs-slide": "prev",
        children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "carousel-control-prev-icon",
          "aria-hidden": "true"
        }), /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "visually-hidden",
          children: "Previous"
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
        className: "carousel-control-next",
        type: "button",
        "data-bs-target": "#carouselExampleControls",
        "data-bs-slide": "next",
        children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "carousel-control-next-icon",
          "aria-hidden": "true"
        }), /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "visually-hidden",
          children: "Next"
        })]
      })]
    })
  });
};

/* harmony default export */ var components_PricingSection = (PricingSection);
// EXTERNAL MODULE: ./config/index.js
var config = __webpack_require__(1130);
;// CONCATENATED MODULE: ./components/Video.js


const video = () => {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    children: /*#__PURE__*/jsx_runtime_.jsx("video", {
      playsInline: true,
      autoPlay: true,
      loop: true,
      muted: true,
      id: "timelapseVideo",
      poster: "/images/timelapseStillImage.png",
      children: /*#__PURE__*/jsx_runtime_.jsx("source", {
        src: "/videos/timelapseCity.webm",
        type: "video/webm"
      })
    })
  });
};

/* harmony default export */ var Video = (video);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
;// CONCATENATED MODULE: ./pages/index.js










async function getServerSideProps() {
  const [aboutInfoRes, companyInfoRes, pricingInfoRes] = await Promise.all([fetch(`${config/* server */.f}/api/aboutinfoapi`), fetch(`${config/* server */.f}/api/companyinfoapi`), fetch(`${config/* server */.f}/api/pricinginfoapi`)]);
  const [aboutInfo, companyInfo, pricingInfo] = await Promise.all([aboutInfoRes.json(), companyInfoRes.json(), pricingInfoRes.json()]);
  return {
    props: {
      aboutInfo,
      companyInfo,
      pricingInfo
    }
  };
}
function Home({
  aboutInfo,
  companyInfo,
  pricingInfo
}) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/jsx_runtime_.jsx((head_default()), {
      children: /*#__PURE__*/jsx_runtime_.jsx("title", {
        children: "OB&T Dispatching Service"
      })
    }), /*#__PURE__*/jsx_runtime_.jsx(Video, {}), /*#__PURE__*/jsx_runtime_.jsx("main", {
      className: "main",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "m-auto",
        children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
          className: "text-center display-1",
          children: "OB&T"
        }), /*#__PURE__*/jsx_runtime_.jsx("h1", {
          className: "head-section text-center text-uppercase display-3",
          children: "Dispatching Service, LLC"
        }), /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "text-center fs-5 fst-italic",
          children: " Our top priority is to ensure we are meeting all of your needs in a timely and professional manner at all times. We have built our business on a strong foundation which includes honesty, respect, integrity, and hard work. Effective communication is one of our key principles which is why we will always strive to communicate with our clients one-on-one to understand their specific needs and provide assistance based on those needs. No Empty Wagons!"
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "d-grid gap-2 d-md-block py-4 text-center",
          children: /*#__PURE__*/jsx_runtime_.jsx("button", {
            type: "button",
            className: "btn border-3 btn-light btn-lg mx-2 shadow-lg",
            children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: "/requestservices",
              children: "Request Service"
            })
          })
        })]
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("section", {
      className: "about-section",
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "py-4",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "row justify-content-sm-center",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "col col-lg-4 m-3",
            children: /*#__PURE__*/jsx_runtime_.jsx("hr", {})
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "col col-md-auto border border-3 m-auto",
            children: /*#__PURE__*/jsx_runtime_.jsx("h3", {
              className: "text-uppercase text-center m-2",
              children: "Professional Service"
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "col col-lg-4 m-3",
            children: /*#__PURE__*/jsx_runtime_.jsx("hr", {})
          })]
        })
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("section", {
      id: "about-section",
      className: "about-section py-5",
      children: /*#__PURE__*/jsx_runtime_.jsx(components_AboutSection, {
        aboutInfo: aboutInfo
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("section", {
      className: "pricing-section",
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "py-5",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "row justify-content-md-center",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "col col-lg-4 m-3",
            children: /*#__PURE__*/jsx_runtime_.jsx("hr", {})
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "col-md-auto border border-3 m-auto",
            children: /*#__PURE__*/jsx_runtime_.jsx("h3", {
              className: "text-uppercase text-center m-2",
              children: "What Sets Us Apart"
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "col col-lg-4 m-3",
            children: /*#__PURE__*/jsx_runtime_.jsx("hr", {})
          })]
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(components_PricingSection, {
        pricingInfo: pricingInfo
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(ContactSection/* default */.Z, {
      companyInfo: companyInfo
    })]
  });
}

/***/ }),

/***/ 5273:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/head.js");;

/***/ }),

/***/ 8417:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router-context.js");;

/***/ }),

/***/ 2238:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");;

/***/ }),

/***/ 5519:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/to-base-64.js");;

/***/ }),

/***/ 444:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/server/image-config.js");;

/***/ }),

/***/ 701:
/***/ (function(module) {

"use strict";
module.exports = require("next/head");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ 5282:
/***/ (function(module) {

"use strict";
module.exports = require("react/jsx-runtime");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [821,675,664,317], function() { return __webpack_exec__(7273); });
module.exports = __webpack_exports__;

})();