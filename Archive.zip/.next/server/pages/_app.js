(function() {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 6828:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "t": function() { return /* binding */ companyInfo; }
/* harmony export */ });
const companyInfo = [{
  name: "OB&T Dispatching Service",
  short: "OB&T",
  phone: "(404) 720-5819",
  email: "info@obtdispatchingservice.com",
  image: {
    url: "/images/logo copy.png",
    width: "200",
    height: "200",
    alt: "ob&t company logo"
  }
}];

/***/ }),

/***/ 1406:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ _app; }
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(701);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./data/companyinfo.js
var companyinfo = __webpack_require__(6828);
;// CONCATENATED MODULE: ./components/Header.js







const Header = () => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)((head_default()), {
      children: [/*#__PURE__*/jsx_runtime_.jsx("meta", {
        name: "description",
        content: "Professional dispatching services based in southwest Georgia"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        name: "keywords",
        content: "Designed by Bivens Blueprint LLC, dispatching, trucking, Georgia"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        name: "viewport",
        content: "width=device-width, initial-scale=1"
      }), /*#__PURE__*/jsx_runtime_.jsx("link", {
        rel: "canonical",
        href: "https.obandt.bivensblueprint.com"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        name: "robots",
        content: "index, follow"
      }), /*#__PURE__*/jsx_runtime_.jsx("link", {
        href: "https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css",
        rel: "stylesheet",
        integrity: "sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC",
        crossOrigin: "anonymous"
      }), /*#__PURE__*/jsx_runtime_.jsx("link", {
        href: "https://fonts.googleapis.com/icon?family=Material+Icons",
        rel: "stylesheet"
      }), /*#__PURE__*/jsx_runtime_.jsx("link", {
        rel: "preconnect",
        href: "https://fonts.googleapis.com"
      }), /*#__PURE__*/jsx_runtime_.jsx("link", {
        rel: "preconnect",
        href: "https://fonts.gstatic.com",
        crossOrigin: true
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("nav", {
      className: "navbar navbar-expand-md navbar-dark",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "container-fluid px-5",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "me-5",
          children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "/",
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                className: "OB&T logo",
                src: "/images/logo_crop.png",
                layout: "intrinsic",
                width: 100,
                height: 100,
                alt: "OB&T Logo"
              })
            })
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("button", {
          className: "navbar-toggler",
          type: "button",
          "data-bs-toggle": "collapse",
          "data-bs-target": "#navbarOBandT",
          "aria-controls": "navbarOBandT",
          "aria-expanded": "false",
          "aria-label": "Toggle navigation",
          children: /*#__PURE__*/jsx_runtime_.jsx("span", {
            className: "navbar-toggler-icon"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "collapse navbar-collapse justify-content-evenly text-center",
          id: "navbarOBandT",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "navbar-nav",
            children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: "/",
              "aria-current": "page",
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                className: "nav-link px-5 fs-6 text-uppercase rounded",
                children: /*#__PURE__*/jsx_runtime_.jsx("h2", {
                  className: "text-secondary fs-3",
                  children: "Home"
                })
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: "/aboutus",
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                className: "nav-link px-5 fs-6 text-uppercase rounded",
                children: /*#__PURE__*/jsx_runtime_.jsx("h2", {
                  className: "text-secondary fs-3",
                  children: "About"
                })
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: "/requestservices",
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                className: "nav-link fs-6 text-uppercase rounded",
                children: /*#__PURE__*/jsx_runtime_.jsx("h2", {
                  className: "text-secondary fs-3",
                  children: "Request Service"
                })
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: "/contact",
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                className: "nav-link px-5 fs-6 text-uppercase rounded",
                children: /*#__PURE__*/jsx_runtime_.jsx("h2", {
                  className: "text-secondary fs-3",
                  children: "Contact Us"
                })
              })
            })]
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
          href: "tel:+14047205819",
          className: "nav-link border rounded border-2",
          children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
            className: "material-icons text-white align-middle",
            children: "phone"
          }), "  ", companyinfo/* companyInfo.0.phone */.t[0].phone]
        })]
      })
    })]
  });
};

/* harmony default export */ var components_Header = (Header);
;// CONCATENATED MODULE: external "next/script"
var script_namespaceObject = require("next/script");;
var script_default = /*#__PURE__*/__webpack_require__.n(script_namespaceObject);
;// CONCATENATED MODULE: ./components/Footer.js




const Footer = () => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("footer", {
      className: "footer py-4 background",
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "text-muted text-center fs-5",
        children: "Copyright \xA9 2021 OB&T Dispatching Service, LLC"
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "text-muted text-center",
        children: ["Designed by ", /*#__PURE__*/jsx_runtime_.jsx("a", {
          href: "http://www.bivensblueprint.com",
          className: "text-decoration-none",
          children: "Bivens Blueprint, LLC"
        })]
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx((script_default()), {
      src: "https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js",
      integrity: "sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM",
      crossOrigin: "anonymous"
    })]
  });
};

/* harmony default export */ var components_Footer = (Footer);
;// CONCATENATED MODULE: ./components/Layout.js





const Layout = ({
  children
}) => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/jsx_runtime_.jsx(components_Header, {}), children, /*#__PURE__*/jsx_runtime_.jsx(components_Footer, {})]
  });
};

/* harmony default export */ var components_Layout = (Layout);
;// CONCATENATED MODULE: ./pages/_app.js


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




function MyApp({
  Component,
  pageProps
}) {
  return /*#__PURE__*/jsx_runtime_.jsx(components_Layout, {
    children: /*#__PURE__*/jsx_runtime_.jsx(Component, _objectSpread({}, pageProps))
  });
}

/* harmony default export */ var _app = (MyApp);

/***/ }),

/***/ 5273:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/head.js");;

/***/ }),

/***/ 8417:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router-context.js");;

/***/ }),

/***/ 2238:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");;

/***/ }),

/***/ 5519:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/to-base-64.js");;

/***/ }),

/***/ 444:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/server/image-config.js");;

/***/ }),

/***/ 701:
/***/ (function(module) {

"use strict";
module.exports = require("next/head");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ 5282:
/***/ (function(module) {

"use strict";
module.exports = require("react/jsx-runtime");;

/***/ }),

/***/ 4453:
/***/ (function() {

/* (ignored) */

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [821,675,664], function() { return __webpack_exec__(1406); });
module.exports = __webpack_exports__;

})();