(function() {
var exports = {};
exports.id = 265;
exports.ids = [265];
exports.modules = {

/***/ 1130:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "f": function() { return /* binding */ server; }
/* harmony export */ });
const dev = false;
const server = dev ? 'http://localhost:3000' : 'https://obtdispatchingservice.com';

/***/ }),

/***/ 7738:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ requestservices; },
  "getServerSideProps": function() { return /* binding */ getServerSideProps; }
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
;// CONCATENATED MODULE: ./components/RequestFormSent.js



const RequestFormSent = () => {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "background",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "container py-5 text-center",
      children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
        className: "fw-bold text-light pt-3",
        children: "Thank you. Form has been sent. "
      }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
        className: "fw-bold text-light pt-3",
        children: "We will follow up with you with additional details."
      })]
    })
  });
};

/* harmony default export */ var components_RequestFormSent = (RequestFormSent);
;// CONCATENATED MODULE: ./components/RequestForm.js






const RequestForm = () => {
  const {
    0: fName,
    1: setfName
  } = (0,external_react_.useState)('');
  const {
    0: lName,
    1: setlName
  } = (0,external_react_.useState)('');
  const {
    0: cName,
    1: setcName
  } = (0,external_react_.useState)('');
  const {
    0: Email,
    1: setEmail
  } = (0,external_react_.useState)('');
  const {
    0: Address,
    1: setAddress
  } = (0,external_react_.useState)(''); // const [Address2, setAddress2] = useState('');

  const {
    0: City,
    1: setCity
  } = (0,external_react_.useState)('');
  const {
    0: Zip,
    1: setZip
  } = (0,external_react_.useState)('');
  const {
    0: USState,
    1: setState
  } = (0,external_react_.useState)('');
  const {
    0: tType,
    1: settType
  } = (0,external_react_.useState)('');
  const [freightGuard, setfreightGuard] = external_react_default().useState('');
  const {
    0: region48,
    1: setRegion48
  } = (0,external_react_.useState)('');
  const {
    0: Southeast,
    1: setSoutheast
  } = (0,external_react_.useState)('');
  const {
    0: Southwest,
    1: setSouthwest
  } = (0,external_react_.useState)('');
  const {
    0: Northeast,
    1: setNortheast
  } = (0,external_react_.useState)('');
  const {
    0: Midwest,
    1: setMidwest
  } = (0,external_react_.useState)('');
  const {
    0: WestCoast,
    1: setWestCoast
  } = (0,external_react_.useState)('');
  const {
    0: processing,
    1: setProcessing
  } = (0,external_react_.useState)('');
  const {
    0: succeeded,
    1: setSucceeded
  } = (0,external_react_.useState)(false);

  const handleRegion = () => {
    setRegion48(!region48);
  };

  const handleSoutheast = () => {
    setSoutheast(!Southeast);
  };

  const handleSouthwest = () => {
    setSouthwest(!Southwest);
  };

  const handleNortheast = () => {
    setNortheast(!Northeast);
  };

  const handleMidwest = () => {
    setMidwest(!Midwest);
  };

  const handleWestCoast = () => {
    setWestCoast(!WestCoast);
  };

  const submitRequest = async e => {
    e.preventDefault();
    setProcessing(true);
    const response = await fetch("/api/servicerequest", {
      method: 'POST',
      headers: {
        'Content-type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({
        fName,
        lName,
        cName,
        Email,
        Address,
        City,
        Zip,
        USState,
        tType,
        freightGuard,
        region48,
        Southeast,
        Southeast,
        Southwest,
        Northeast,
        Midwest,
        WestCoast
      })
    });
    const resData = await response.json();

    if (resData.status === 'success') {
      setProcessing(false);
      setSucceeded(true);
    } else if (resData.status === 'fail') {
      setProcessing(false);
      alert("Message failed to send.");
    }
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "container",
    children: [/*#__PURE__*/jsx_runtime_.jsx("h4", {
      className: "text-center display-6 mb-5",
      children: "Please Complete the Form Below"
    }), succeeded ? /*#__PURE__*/jsx_runtime_.jsx(components_RequestFormSent, {}) : /*#__PURE__*/(0,jsx_runtime_.jsxs)("form", {
      className: "dispatch-form row g-2 border border-3 rounded py-4 bg-dark",
      onSubmit: submitRequest,
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "col-md-6 form-floating",
        children: [/*#__PURE__*/jsx_runtime_.jsx("input", {
          type: "text",
          value: fName,
          className: "form-control",
          id: "first name",
          placeholder: "FirstName",
          required: true,
          onChange: e => setfName(e.target.value)
        }), /*#__PURE__*/jsx_runtime_.jsx("label", {
          htmlFor: "first name",
          className: "text-secondary",
          children: "First Name"
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "col-md-6 form-floating",
        children: [/*#__PURE__*/jsx_runtime_.jsx("input", {
          type: "text",
          value: lName,
          className: "form-control",
          id: "last name",
          placeholder: "Last Name",
          required: true,
          onChange: e => setlName(e.target.value)
        }), /*#__PURE__*/jsx_runtime_.jsx("label", {
          htmlFor: "last name",
          className: "text-secondary",
          children: "Last Name"
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "col-md-12 form-floating",
        children: [/*#__PURE__*/jsx_runtime_.jsx("input", {
          type: "text",
          value: cName,
          className: "form-control",
          id: "company name",
          placeholder: "Company Name",
          onChange: e => setcName(e.target.value)
        }), /*#__PURE__*/jsx_runtime_.jsx("label", {
          htmlFor: "company name",
          className: "text-secondary",
          children: "Company Name"
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "col-md-12 form-floating",
        children: [/*#__PURE__*/jsx_runtime_.jsx("input", {
          type: "email",
          value: Email,
          className: "form-control",
          id: "email address",
          placeholder: "Email Address",
          onChange: e => setEmail(e.target.value)
        }), /*#__PURE__*/jsx_runtime_.jsx("label", {
          htmlFor: "email address",
          className: "text-secondary",
          children: "Email Address"
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "col-12 form-floating",
        children: [/*#__PURE__*/jsx_runtime_.jsx("input", {
          type: "text",
          value: Address,
          className: "form-control",
          id: "street address",
          placeholder: "Street Address",
          required: true,
          onChange: e => setAddress(e.target.value)
        }), /*#__PURE__*/jsx_runtime_.jsx("label", {
          htmlFor: "street address",
          className: "text-secondary",
          children: "Street Address"
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "col-md-6 form-floating",
        children: [/*#__PURE__*/jsx_runtime_.jsx("input", {
          type: "text",
          value: City,
          className: "form-control",
          id: "city",
          placeholder: "City",
          required: true,
          onChange: e => setCity(e.target.value)
        }), /*#__PURE__*/jsx_runtime_.jsx("label", {
          htmlFor: "city",
          className: "text-secondary",
          children: "City"
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "col-md-4 form-floating",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
          className: "form-select",
          value: USState,
          id: "USState",
          placeholder: "State",
          required: true,
          onChange: event => setState(event.target.value),
          children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "",
            children: "Select State..."
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "AL",
            children: "Alabama"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "AK",
            children: "Alaska"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "AZ",
            children: "Arizona"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "AR",
            children: "Arkansas"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "CA",
            children: "California"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "CO",
            children: "Colorado"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "CT",
            children: "Connecticut"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "DE",
            children: "Delaware"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "DC",
            children: "District Of Columbia"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "FL",
            children: "Florida"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "GA",
            children: "Georgia"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "HI",
            children: "Hawaii"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "ID",
            children: "Idaho"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "IL",
            children: "Illinois"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "IN",
            children: "Indiana"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "IA",
            children: "Iowa"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "KS",
            children: "Kansas"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "KY",
            children: "Kentucky"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "LA",
            children: "Louisiana"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "ME",
            children: "Maine"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "MD",
            children: "Maryland"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "MA",
            children: "Massachusetts"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "MI",
            children: "Michigan"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "MN",
            children: "Minnesota"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "MS",
            children: "Mississippi"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "MO",
            children: "Missouri"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "MT",
            children: "Montana"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "NE",
            children: "Nebraska"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "NV",
            children: "Nevada"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "NH",
            children: "New Hampshire"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "NJ",
            children: "New Jersey"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "NM",
            children: "New Mexico"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "NY",
            children: "New York"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "NC",
            children: "North Carolina"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "ND",
            children: "North Dakota"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "OH",
            children: "Ohio"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "OK",
            children: "Oklahoma"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "OR",
            children: "Oregon"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "PA",
            children: "Pennsylvania"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "RI",
            children: "Rhode Island"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "SC",
            children: "South Carolina"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "SD",
            children: "South Dakota"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "TN",
            children: "Tennessee"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "TX",
            children: "Texas"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "UT",
            children: "Utah"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "VT",
            children: "Vermont"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "VA",
            children: "Virginia"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "WA",
            children: "Washington"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "WV",
            children: "West Virginia"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "WI",
            children: "Wisconsin"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "WY",
            children: "Wyoming"
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("label", {
          htmlFor: "USState",
          className: "text-secondary",
          children: "Select State"
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "col-md-2 form-floating",
        children: [/*#__PURE__*/jsx_runtime_.jsx("input", {
          type: "text",
          value: Zip,
          className: "form-control",
          id: "zip",
          placeholder: "Zip Code",
          required: true,
          onChange: e => setZip(e.target.value)
        }), /*#__PURE__*/jsx_runtime_.jsx("label", {
          htmlFor: "zip",
          className: "text-secondary",
          children: "Zip Code"
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("hr", {
        className: "my-4"
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "col-md-4 text-center px-3",
        children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
          htmlFor: "trailer type",
          className: "text-Light pb-3 fs-4",
          children: "Trailer Type"
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
          className: "form-select",
          value: tType,
          id: "trailer type",
          placeholder: "Trailer Type",
          onChange: e => settType(e.target.value),
          children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
            selected: true,
            children: "Choose One..."
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            children: "Dry Van"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            children: "Flat Bed"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            children: "Step Deck"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            children: "Reefer"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            children: "Other"
          })]
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "col-md-4 px-3 border border-top-0 border-bottom-0",
        value: freightGuard,
        onChange: e => setfreightGuard(e.target.value),
        children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
          htmlFor: "fGuard",
          className: "form-label text-center fs-4",
          children: "Do you have any Freight Guard Reports?"
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "form-check",
          children: [/*#__PURE__*/jsx_runtime_.jsx("input", {
            className: "form-check-input",
            type: "radio",
            name: "FreightGuard",
            value: "Yes",
            id: "fGuard"
          }), /*#__PURE__*/jsx_runtime_.jsx("label", {
            className: "form-check-label",
            htmlFor: "FreightGuard",
            children: "Yes"
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "form-check",
          children: [/*#__PURE__*/jsx_runtime_.jsx("input", {
            className: "form-check-input",
            type: "radio",
            name: "FreightGuard",
            value: "No",
            id: "fGuard"
          }), /*#__PURE__*/jsx_runtime_.jsx("label", {
            className: "form-check-label",
            htmlFor: "FreightGuard",
            children: "No"
          })]
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "col-md-4 text-center px-5",
        children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
          htmlFor: "Region",
          className: "form-label text-center fs-4",
          children: "Region"
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "form-check",
          children: [/*#__PURE__*/jsx_runtime_.jsx("input", {
            className: "form-check-input",
            type: "checkbox",
            value: region48,
            onChange: handleRegion,
            name: "item"
          }), /*#__PURE__*/jsx_runtime_.jsx("label", {
            className: "form-check-label text-start",
            htmlFor: "Region",
            name: "48-states",
            children: "48 States"
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "form-check",
          children: [/*#__PURE__*/jsx_runtime_.jsx("input", {
            className: "form-check-input",
            type: "checkbox",
            onChange: handleSoutheast,
            value: Southeast
          }), /*#__PURE__*/jsx_runtime_.jsx("label", {
            className: "form-check-label",
            name: "Southeast",
            children: "Southeast"
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "form-check",
          children: [/*#__PURE__*/jsx_runtime_.jsx("input", {
            className: "form-check-input",
            type: "checkbox",
            onChange: handleSouthwest,
            value: Southwest
          }), /*#__PURE__*/jsx_runtime_.jsx("label", {
            className: "form-check-label",
            name: "Southwest",
            children: "Southwest"
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "form-check",
          children: [/*#__PURE__*/jsx_runtime_.jsx("input", {
            className: "form-check-input",
            type: "checkbox",
            onChange: handleNortheast,
            value: Northeast
          }), /*#__PURE__*/jsx_runtime_.jsx("label", {
            className: "form-check-label",
            name: "Northeast",
            children: "Northeast"
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "form-check",
          children: [/*#__PURE__*/jsx_runtime_.jsx("input", {
            className: "form-check-input",
            type: "checkbox",
            onChange: handleMidwest,
            value: Midwest
          }), /*#__PURE__*/jsx_runtime_.jsx("label", {
            className: "form-check-label",
            name: "Midwest",
            children: "Midwest"
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "form-check",
          children: [/*#__PURE__*/jsx_runtime_.jsx("input", {
            className: "form-check-input",
            type: "checkbox",
            onChange: handleWestCoast,
            value: WestCoast
          }), /*#__PURE__*/jsx_runtime_.jsx("label", {
            className: "form-check-label",
            name: "West Coast",
            children: "West Coast"
          })]
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "form-group text-center py-3",
        children: /*#__PURE__*/jsx_runtime_.jsx("button", {
          disabled: processing || succeeded,
          id: "submit",
          className: "btn btn-primary w-25",
          type: "submit",
          children: /*#__PURE__*/jsx_runtime_.jsx("span", {
            id: "button-text",
            children: processing ? /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "spinner-border text-light",
              role: "status"
            }) : "Send Request"
          })
        })
      })]
    })]
  });
};

/* harmony default export */ var components_RequestForm = (RequestForm);
;// CONCATENATED MODULE: ./components/ServicesCard.js



const ServicesCard = props => {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "col-lg py-2",
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "service-card border h-100 rounded",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "card-body",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "text-center",
          children: /*#__PURE__*/jsx_runtime_.jsx("span", {
            className: "material-icons mi-service",
            children: props.image
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
          className: "card-title text-center",
          children: props.name
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "container",
          children: /*#__PURE__*/jsx_runtime_.jsx("ul", {
            className: "text-light m-auto",
            children: props.data.map(data => /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
              children: [" ", /*#__PURE__*/jsx_runtime_.jsx("span", {
                className: "material-icons align-middle text-white",
                children: "check_circle"
              }), " ", data, " "]
            }, props.id))
          })
        })]
      })
    })
  });
};

/* harmony default export */ var components_ServicesCard = (ServicesCard);
;// CONCATENATED MODULE: ./components/ServicesSection.js




function createServiceCard(servicesInfo) {
  return /*#__PURE__*/jsx_runtime_.jsx(components_ServicesCard, {
    image: servicesInfo.image,
    name: servicesInfo.name,
    data: servicesInfo.data
  }, servicesInfo.id);
}

const ServicesSection = props => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "container",
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "row",
      children: props.servicesInfo.slice(0, 3).map(createServiceCard)
    }, props.id), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "row",
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "col-lg-12",
        children: props.servicesInfo.slice(3, 4).map(createServiceCard)
      })
    }, props.id)]
  });
};

/* harmony default export */ var components_ServicesSection = (ServicesSection);
// EXTERNAL MODULE: ./config/index.js
var config = __webpack_require__(1130);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(701);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
;// CONCATENATED MODULE: ./pages/requestservices.js






async function getServerSideProps() {
  const res = await fetch(`${config/* server */.f}/api/servicesinfoapi`);
  const servicesInfo = await res.json();
  return {
    props: {
      servicesInfo
    }
  };
}

const requestervices = ({
  servicesInfo
}) => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "background",
    children: [/*#__PURE__*/jsx_runtime_.jsx((head_default()), {
      children: /*#__PURE__*/jsx_runtime_.jsx("title", {
        children: "OB&T | Request Services"
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("h1", {
      className: "text-uppercase text-center text-black contact-title py-3",
      children: "Obtain Dispatch Service"
    }), /*#__PURE__*/jsx_runtime_.jsx(components_ServicesSection, {
      servicesInfo: servicesInfo
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "d-grid gap-2 py-4 d-md-flex justify-content-center",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
        href: "/documents/OB&T Dispatching Service Dispatch and Carrier Agreement2.pdf",
        download: true,
        children: [" ", /*#__PURE__*/jsx_runtime_.jsx("button", {
          className: "btn btn-primary me-md-2",
          style: {
            width: 16 + 'em'
          },
          type: "button",
          children: " Download the Dispatch/Carrier Agreement"
        })]
      })
    }), /*#__PURE__*/jsx_runtime_.jsx(components_RequestForm, {})]
  });
};

/* harmony default export */ var requestservices = (requestervices);

/***/ }),

/***/ 5273:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/head.js");;

/***/ }),

/***/ 5519:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/to-base-64.js");;

/***/ }),

/***/ 444:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/server/image-config.js");;

/***/ }),

/***/ 701:
/***/ (function(module) {

"use strict";
module.exports = require("next/head");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ 5282:
/***/ (function(module) {

"use strict";
module.exports = require("react/jsx-runtime");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [821,675], function() { return __webpack_exec__(7738); });
module.exports = __webpack_exports__;

})();