(function() {
var exports = {};
exports.id = 91;
exports.ids = [91];
exports.modules = {

/***/ 5667:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ handler; }
/* harmony export */ });
function handler(req, res) {
  __webpack_require__(334).config();

  const HOST = "obtdispatchingservice.com";
  const PASS = "invalidemail";
  const USER = "invalidemail@obtdispatchingservice.com";

  const nodemailer = __webpack_require__(8123);

  const smtpTrans = nodemailer.createTransport({
    host: HOST,
    port: 465,
    secure: true,
    auth: {
      user: USER,
      pass: PASS
    }
  });
  const mailOpts = {
    from: 'invalidemail@obtdispatchingservice.com',
    replyTo: `${req.body.Email}`,
    to: 'info@obtdispatchingservice.com',
    subject: `Message from OB&T!`,
    html: `
                    <h4><b>Name:</b></h4> ${req.body.Name} <br> 
                    <h4><b>Phone:</b></h4> ${req.body.Phone} <br> 
                    <h4><b>Email:</b></h4> ${req.body.Email} <br> 
                    <h4><b>Message:</b></h4> ${req.body.Message}
                    `
  };
  smtpTrans.sendMail(mailOpts, function (err, success) {
    if (err) {
      res.json({
        status: 'fail'
      });
      console.log(err);
    } else {
      res.json({
        status: 'success'
      });
    }
  });
}
;

/***/ }),

/***/ 334:
/***/ (function(module) {

"use strict";
module.exports = require("dotenv");;

/***/ }),

/***/ 8123:
/***/ (function(module) {

"use strict";
module.exports = require("nodemailer");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = (__webpack_exec__(5667));
module.exports = __webpack_exports__;

})();