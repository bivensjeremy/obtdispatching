(function() {
var exports = {};
exports.id = 586;
exports.ids = [586];
exports.modules = {

/***/ 495:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ handler; }
});

;// CONCATENATED MODULE: ./data/servicesinfo.js
const servicesInfo = [// {
//     id: 1,
//     image: "local_shipping",
//     name: "Truck Load",
//     data: [
//         ]
//   },
{
  id: 2,
  image: "local_shipping",
  name: "Truck Types",
  data: ["Dry Van", "Reefer", "Flatbed", "Hotshot", "Step Decks"]
}, {
  id: 3,
  image: "description",
  name: "Paperwork",
  data: ["Carrier Packet Setup for each Broker/Shipment", "Truck Order Not Used (TONO) Assistance"]
}, {
  id: 4,
  image: "headset_mic",
  name: "Customer Service",
  data: ["24/7 Support", "Text Confirmations"]
}, {
  id: 5,
  image: "location_on",
  name: "What to Get Started",
  data: ["Download and Complete the Dispatch/Carrier Agreement", "Submit the Request Form below", "Active Authority", "Copy of CDL for Each Driver Being Dispatched", "Signed W-9", "Signed Dispatch/Carrier Agreement and Power of Attorney", "Proof of Insurance: $1,000,000 Auto-Liability and $100,00 Cargo Coverage"]
}];
;// CONCATENATED MODULE: ./pages/api/servicesinfoapi.js

function handler(req, res) {
  res.status(200).json(servicesInfo);
}

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = (__webpack_exec__(495));
module.exports = __webpack_exports__;

})();