(function() {
var exports = {};
exports.id = 47;
exports.ids = [47];
exports.modules = {

/***/ 6828:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "t": function() { return /* binding */ companyInfo; }
/* harmony export */ });
const companyInfo = [{
  name: "OB&T Dispatching Service",
  short: "OB&T",
  phone: "(404) 720-5819",
  email: "info@obtdispatchingservice.com",
  image: {
    url: "/images/logo copy.png",
    width: "200",
    height: "200",
    alt: "ob&t company logo"
  }
}];

/***/ }),

/***/ 5420:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ handler; }
/* harmony export */ });
/* harmony import */ var _data_companyinfo__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6828);

function handler(req, res) {
  res.status(200).json(_data_companyinfo__WEBPACK_IMPORTED_MODULE_0__/* .companyInfo */ .t);
}

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = (__webpack_exec__(5420));
module.exports = __webpack_exports__;

})();