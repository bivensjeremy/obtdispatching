(function() {
var exports = {};
exports.id = 994;
exports.ids = [994];
exports.modules = {

/***/ 7294:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ handler; }
/* harmony export */ });
function handler(req, res) {
  __webpack_require__(334).config();

  const HOST = "obtdispatchingservice.com";
  const PASS = "invalidemail";
  const USER = "invalidemail@obtdispatchingservice.com";

  const nodemailer = __webpack_require__(8123);

  const smtpTrans = nodemailer.createTransport({
    host: HOST,
    port: 465,
    secure: true,
    auth: {
      user: USER,
      pass: PASS
    }
  });
  const mailOpts = {
    from: 'invalidemail@obtdispatchingservice.com',
    replyTo: `${req.body.Email}`,
    to: 'info@obtdispatchingservice.com',
    subject: `OBT Request Form`,
    html: `
                <table>
                    <tr>
                        <th>Name:</th>
                        <td>${req.body.fName} ${req.body.lName}</td>
                    </tr>
                    <tr>
                        <th>Company Name:</th>
                        <td>${req.body.cName}</td>
                    </tr>
                    <tr>
                        <th>Email:</th>
                        <td>${req.body.Email}</td>
                    </tr>
                    <tr>
                        <th>Street Address:</th>
                        <td>${req.body.Address}</td>
                    </tr>
                    <tr>
                        <th>City:</th>
                        <td>${req.body.City}</td>
                    </tr>
                    <tr>
                        <th>State:</th>
                        <td>${req.body.State}</td>
                    </tr>
                    <tr>
                        <th>Zip:</th>
                        <td>${req.body.Zip}</td>
                    </tr>
                    <tr>
                        <th>Dispatch Request Information</th>
                    </tr>
                    <tr>
                        <th>Trailer Type:</th>
                        <td>${req.body.tType}</td>
                    </tr>
                    <tr>
                        <th>Freight Guard:</th>
                        <td>${req.body.freightGuard}</td>
                    </tr>
                    
                        <tr>
                            <th>48 States:</th>
                            <td>${req.body.region48}</td>
                        </tr>
                        <tr>
                            <th>Southeast: </th>
                            <td>${req.body.Southeast}</td> 
                        </tr>
                        <tr>
                            <th>Southwest: </th>
                            <td>${req.body.Southwest}</td> 
                        </tr>
                        <tr>
                            <th>Northeast: </th>
                            <td>${req.body.Northeast}</td>
                        </tr>
                       <tr>
                            <th>Midwest: </th>
                            <td>${req.body.Midwest}</td> 
                       </tr>
                        <tr>
                            <th>West Coast: </th>
                            <td>${req.body.WestCoast}</td> 
                        </tr>
                </table>
                    `
  };
  smtpTrans.sendMail(mailOpts, function (err, success) {
    if (err) {
      res.json({
        status: 'fail'
      });
      console.log(err);
    } else {
      res.json({
        status: 'success'
      });
    }
  });
}
;

/***/ }),

/***/ 334:
/***/ (function(module) {

"use strict";
module.exports = require("dotenv");;

/***/ }),

/***/ 8123:
/***/ (function(module) {

"use strict";
module.exports = require("nodemailer");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = (__webpack_exec__(7294));
module.exports = __webpack_exports__;

})();