(function() {
var exports = {};
exports.id = 399;
exports.ids = [399];
exports.modules = {

/***/ 6289:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ handler; }
});

;// CONCATENATED MODULE: ./data/pricinginfo.js
const pricingInfo = [{
  id: 1,
  active: "active",
  icon: "message",
  name: "Communication",
  data: "Simple and direct communication between client & dispatcher"
}, {
  id: 2,
  active: "",
  icon: "account_balance_wallet",
  name: "Trusted Experience",
  data: "Over 5 years of industry experience"
}, {
  id: 3,
  active: "",
  icon: "request_quote",
  name: "Rate Plan",
  data: "Flat fee of 10% per load"
}];
;// CONCATENATED MODULE: ./pages/api/pricinginfoapi.js

function handler(req, res) {
  res.status(200).json(pricingInfo);
}

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = (__webpack_exec__(6289));
module.exports = __webpack_exports__;

})();