export const pricingInfo = [
    {
      id: 1,
      active: "active",
      icon: "message",
      name: "Communication",
      data: "Simple and direct communication between client & dispatcher"
    },
    {
      id: 2,
      active: "",
      icon: "account_balance_wallet",
      name: "Trusted Experience",
      data: "Over 5 years of industry experience"
    },
    {
      id: 3,
      active: "",
      icon: "request_quote",
      name: "Rate Plan",
      data: "Flat fee of 10% per load"
    }
]