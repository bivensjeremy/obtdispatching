export const companyInfo = [
    {
        name: "OB&T Dispatching Service",
        short: "OB&T",
        phone: "(404) 720-5819",
        email: "info@obtdispatchingservice.com",
        image: {
            url: "/images/logo copy.png",
            width: "200",
            height: "200",
            alt: "ob&t company logo"
        }
    }
]