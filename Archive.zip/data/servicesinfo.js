export const servicesInfo = [
    // {
    //     id: 1,
    //     image: "local_shipping",
    //     name: "Truck Load",
    //     data: [
    //         ]
    //   },
      {
        id: 2,
        image: "local_shipping",
        name: "Truck Types",
        data: [
            "Dry Van",
            "Reefer",
            "Flatbed",
            "Hotshot",
            "Step Decks"]
      },
      {
          id: 3,
          image: "description",
          name: "Paperwork",
          data: [
              "Carrier Packet Setup for each Broker/Shipment",
              "Truck Order Not Used (TONO) Assistance"
          ]
      },
      {
          id: 4,
          image: "headset_mic",
          name: "Customer Service",
          data: [
              "24/7 Support",
              "Text Confirmations"
          ]
      },
      {
          id: 5,
          image: "location_on",
          name: "What to Get Started",
          data: [
              "Download and Complete the Dispatch/Carrier Agreement",
              "Submit the Request Form below",
              "Active Authority",
              "Copy of CDL for Each Driver Being Dispatched",
              "Signed W-9",
              "Signed Dispatch/Carrier Agreement and Power of Attorney",
              "Proof of Insurance: $1,000,000 Auto-Liability and $100,00 Cargo Coverage"
              ]
      }
]